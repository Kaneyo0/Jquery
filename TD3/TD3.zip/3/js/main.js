$(function(){
	
	let urlSchema='data/tableschema.json';
	let urlSite ='data/sites.json';

	/** pseudo pour contains non sensible à la casse **/
	$.expr[":"].contains = $.expr.createPseudo(function(arg) {
		return function( elem ) {
			return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
		};
	});
	
	
	/**
	Gestion des événements
	**/
	function eventListener(){
		//click sur la liste des champs
	}
	
	
	/** 
		Chargement du schema dans le menu
	**/	
	function menuDisplay(){
	}
	
	
	/**
	Génère l'entête du tableau à partir des colonnes de la liste
	**/
	function siteAddHeader(table){
	}
	
	/**
	Chargement des sites
	**/
	function siteDisplay(){
		
		let table =$('<table>');
		table.attr('id','sites');
		table.addClass('table table-striped table-bordered');
		siteAddHeader(table);

		//récupération des données
	}

	/**
	 * Masquer/Afficher COlonne
	 *
	 */
	function colonneDisplay(col){
	}

	menuDisplay();
	
	eventListener();
});