/**
 Plugin de personnalisation du tableau : Sélection des lignes
 **/
