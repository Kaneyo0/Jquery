/**
 Plugin de personnalisation du tableau : Tri des données
 **/
(function ( $ ) {

    /**
     * Etudiants
     */
    $.fn.sortable = function( options ) {
        var settings = $.extend({}, options );
        var sortPage = function(colonne, sens){
            console.log("page:", colonne,sens)
        };
        var sortBase =function(colonne, sens){
            console.log("base:",colonne,sens)
        };
        console.log("sortable",this);
        return this;
    };
}( jQuery ));
