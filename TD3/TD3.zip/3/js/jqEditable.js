/**
 Plugin de personnalisation du tableau : modification des données
 **/
(function ( $ ) {
    $.fn.editable = function( options ) {
        var settings = $.extend({}, options );

        console.log("editable")
        return this.each(function(){
            let elem =$(this);

            let tr= elem.find('tbody>tr');


        });
    };


}( jQuery ));
