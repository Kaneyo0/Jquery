/**
 Plugin de personnalisation du tableau
 **/
    //création du formulaire
let form='<form class="filterable">' +
    '<div class="form-group">' +
    '<label for="identifiant">Identifiants</label>' +
    '<input   type="text" class="form-control" id="identifiant"' +
    ' placeholder="Identifiant du site">' +
    '</div>' +
    '<div class="form-group">' +
    '<label for="ville">Ville</label>' +
    '<input type="text" class="form-control" id="ville" placeholder="Ville">' +
    '</div>'+
    '<div class="form-group form-check">'+
    '<label class="form-check-label" >Type de Test : </label>'+
    ' <input type="checkbox" class="form-check-input"  id="pcr">'+
    '<label class="form-check-label" for="pcr">PCR</label>'+
    ' <input type="checkbox" class="form-check-input" id="antigen">'+
    '<label class="form-check-label" for="antigenr">Antigénique</label>'+
    '</div>'+
    '<div class="form-group form-check">'+
    '<label class="form-check-label" >Prélèvement : </label>'+
    ' <input type="checkbox" class="form-check-input"  id="place">'+
    '<label class="form-check-label" for="place">Sur place</label>'+
    ' <input type="checkbox" class="form-check-input" id="drive">'+
    '<label class="form-check-label" for="drive">Drive</label>'+
    '</div>'+
    '</form>';

(function ( $ ) {
    $.fn.filterable = function( options ) {
        var settings = $.extend({}, options );



    };


}( jQuery ));
