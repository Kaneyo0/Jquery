/**
 Plugin de personnalisation du tableau
 **/
(function ( $ ) {
    $.fn.selectable = function( options ) {
        var settings = $.extend({}, options );

        return this.each(function(){
            let elem =$(this);

            /**
             * Sélection d'une ligne
             */
            let checkOne=function(){
                let $me=$(this);
                $me.closest('tr').toggleClass('active');
                console.log($me.closest('tr').attr('id'));
            };

            let checkAll=function(){
                let myStatus = $(this).is(':checked');
                let uncheck=$(".selectable .check-one:not(:checked)");
                $(".selectable .check-one:checked").prop('checked', false);

                elem.find('tbody tr.active').removeClass('active');
                uncheck.trigger('click');
            };
            let tr,chk;
            tr= elem.find('thead>tr');
            chk = $('<th class="selectable"><input class="check-all" type="checkbox"></th>');
            tr.prepend(chk);

            $('body').on('click','.selectable .check-all',checkAll);

            tr= elem.find('tbody>tr');
            chk = $('<td class="selectable"><input class="check-one" type="checkbox"></td>');
            tr.prepend(chk);
            $('body').on('click','.selectable .check-one',checkOne);

        });
    };


}( jQuery ));
