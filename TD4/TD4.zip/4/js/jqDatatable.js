/**
 Plugin de personnalisation du tableau
 **/
(function ( $ ) {
    $.fn.dataTable = function( options ) {
        var settings = $.extend({}, options );
        console.log("dataTable",this);
        return this;
    };
}( jQuery ));
