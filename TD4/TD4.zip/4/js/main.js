$(function(){
	
	let urlSchema='data/tableschema.json';
	let urlSite ='data/sites.json';

	/** pseudo pour contains non sensible à la casse **/
	$.expr[":"].contains = $.expr.createPseudo(function(arg) {
		return function( elem ) {
			return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
		};
	});
	
	
	/**
	Gestion des événements
	**/
	function eventListener(){

		/**Option 1**/
		$('#menu').on('click','#colonnes',function(){
			console.log($(this).val());
		});}

	
	/** 
		Chargement du schema dans le menu
	**/	
	function menuDisplay(){	
		$.getJSON(urlSchema,function(data){
			let sel =$('<select>');
			sel.addClass('colonnes');
			sel.attr('id','colonnes');
			sel.attr('multiple','multiple');
			sel.attr('size',data.fields.length);
			
			$.each(data.fields,function(i,field){
				let option=$('<option>');
				option.val(field.name);
				option.text(field.description);
				option.appendTo(sel);
			});
			sel.appendTo('#menu');
			
			siteDisplay();
		});
	}
	
	
	/**
	Génère l'entête du tableau à partir des colonnes de la liste
	**/
	function siteAddHeader(table){
		let thead =$('<thead>');
		thead.addClass('thead');
		let tr=$('<tr>');
		let cols = $('#colonnes>option');
		cols.each(function(i,opt){
			let $opt= $(opt);
			let th=$('<th class="'+$opt.val()+'">'+$opt.text()+'</th>');
			tr.append(th);
		});
		tr.appendTo(thead);
		table.prepend(thead);
	}
	
	/**
	Chargement des sites
	**/
	function siteDisplay(){
		
		let table =$('<table>');
		table.attr('id','sites');
		table.addClass('table table-striped table-bordered');
		siteAddHeader(table);

		//récupération des colonnes
		let cols = $('#colonnes>option');
		
		$.getJSON(urlSite,function(sites){
			
			$.each(sites,function(i,site){
				
				let tr=$('<tr id="site_'+site.ID+'">');
				
				//traitement des colonnes
				let cols = $('#colonnes>option');
				cols.each(function(j,col){
					let $col=$(col);
					let content =site[$col.val()];
					switch($col.val()) {
						case "do_prel":
							let text1=content;
							let ico1=content==='OUI'?'check':'times';
							content = '<span title="'+ text1+'"><i class="fa fa-'+ico1+'"></i></span>';
							break;
						case "do_antigenic":
							let text2=content;
							let ico2=content==='OUI'?'check':'times';
							content = '<span title="'+ text2+'"><i class="fa fa-'+ico2+'"></i></span>';
							break;
						case "horaire":
						case "horaire_prio":
							content = content===''?'':'<span title="'+content+'"><i class="fas fa-calendar-alt" ></i></span>';
							break;
						case "tel_rdv":
							content =content.replace(/[^\d]/g, "").replace(/(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, "$1 $2 $3 $4 $5");
							break;
						case "date_modif":
							content =(new Date(content)).toLocaleDateString();
							break;
					}

					let td =$('<td class="'+$col.val()+'">'+content+'</td>');
					tr.append(td);
				});
				tr.appendTo(table);
				
				if (i === 9) return false;
			});

			$('td.horaire>span,td.horaire_prio>span').tooltip();

			$('#colonnes')
				.select2()
				.on('select2:select',function (e) {
					var data = e.params.data;
					colonneDisplay(data.id,false);
				})
				.on('select2:unselect',function (e) {
					var data = e.params.data;
					colonneDisplay(data.id,true);
				});

			table.sortable({sortMode: 'page'}).selectable().filterable()


		});


		table.appendTo('#content')

	}

	/**
	 * Masquer/Afficher COlonne
	 *
	 */
	function colonneDisplay(col,status){
		$('#sites .' + col).toggle();
	}

	menuDisplay();
	
	eventListener();
});