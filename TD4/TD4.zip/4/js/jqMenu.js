/**
 Plugin de personnalisation du tableau
 **/
(function ( $ ) {
    $.fn.menu = function( options ) {
        var settings = $.extend({}, options );
        console.log("menu",this);
        return this;
    };
}( jQuery ));
