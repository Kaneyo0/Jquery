$(function(){
	
	let urlSchema='data/tableschema.json';
	let urlSite ='data/sites.json';

	/** pseudo pour contains non sensible à la casse **/
	$.expr[":"].contains = $.expr.createPseudo(function(arg) {
		return function( elem ) {
			return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
		};
	});

	$('#menu').menu({
		url: urlSchema,
		debug:true,
		onloadeddata:function(){
			$('#content').dataTable({
				url:urlSite,
				linkTo:'menu',
				selectable:true,
				sortable:'page',
				filterable:true,
				editable:true
			});
		}
	});
});