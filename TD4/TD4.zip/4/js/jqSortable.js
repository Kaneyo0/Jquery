/**
 Plugin de personnalisation du tableau
 **/
(function ( $ ) {
    $.fn.sortable = function( options ) {
        var settings = $.extend({sortMode:"base"}, options );

        return this.each(function(){
            let elem =$(this);
            let arr ='<span><i class="icon bi"></i></span>';

            //tri des valeurs affichées
            var sortPage = function(colonne, sens){
                console.log("page:",colonne,sens)
            };

            //tri selon les données brutes
            var sortBase =function(colonne, sens){
                console.log("base:",colonne,sens)
            };

        });
    };
}( jQuery ));
