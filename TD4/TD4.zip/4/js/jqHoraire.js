/**
 Plugin de gestion des horaires de prélèvement
 **/
(function ( $ ) {

    $.fn.horaire = function( options ) {

        var settings = $.extend({
            //Param par défaut
            separator: "|",  //Séparateur de date
            tooltip: false, // Librairie tooltip existant
            listClass:"horaires", // classe à affecter à la liste
            itemClass:"date"    //classe à affecter aux éléments interne
        }, options );

        return this.each(function(){
            let elem= $(this);

            let title=  elem.attr('title')
            if(typeof title !== "undefined"){
                elem.attr('title',  elem.attr('title').replaceAll(settings.separator,''));
                if(settings.tooltip) elem.data('html',true).tooltip();

            }
        })

    };

}( jQuery ));
