/**
 Plugin de personnalisation du tableau
 **/
(function ( $ ) {
    $.fn.editable = function( options ) {
        var settings = $.extend({}, options );

        console.log("editable")
        return this.each(function(){
            let elem =$(this);

        });
    };


}( jQuery ));
